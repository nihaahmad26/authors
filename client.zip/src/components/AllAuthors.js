import React, {useState, useEffect} from 'react';
import {Link, navigate} from '@reach/router';
import axios from 'axios';
import Header from './Header';


const AllAuthors = (props)=>{

    const [authorList, setAuthorList] = useState([]);
    
    useEffect(()=>{
        axios.get('http://localhost:8000/api/authors')
            .then((res)=>{
                console.log(res);
                console.log(res.data);
                setAuthorList(res.data);
            })
            .catch((err)=>{
                console.log(err);
            })
    }, [])

    const deleteHandler = (id)=>{
        axios.delete(`http://localhost:8000/api/authors/${id}`)
            .then((res)=>{
                console.log(res.data);
                setAuthorList(authorList.filter((author)=>author._id !== id))
            })
            .catch((err)=>{
                console.log(err);
            })
    }



    return(
        <div>
            <Header link={'/new'} linkText="Add an Author"/>
            <table>
                <thead>
                    <h2>we have quotes by:</h2>
                    <tr>
                        <th>Author</th>
                        <th>Action Available</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        authorList.map((author, index)=>(
                            <tr key={index}>
                                <td>{author.authorName}</td>
                                <td><button onClick={()=>{navigate(`/edit/${author._id}`)}}>Edit</button>
                                <button onClick={(e)=>deleteHandler(author._id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                        
                </tbody>
            </table>
        </div>
    )
}


export default AllAuthors;