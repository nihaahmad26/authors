import React, { useEffect, useState } from 'react';
import AuthorList from '../components/AuthorList';
const Main = () => {
    return (
        <div>
           <AuthorList/>
        </div>
    )
}
export default Main;


